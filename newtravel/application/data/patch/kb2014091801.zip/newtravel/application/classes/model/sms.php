<?php defined('SYSPATH') or die('No direct access allowed.');

class Model_Sms extends ORM {

    protected  $_table_name = 'sms_msg';



}