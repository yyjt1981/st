<?php
require_once(dirname(__FILE__) . "/include/common.inc.php");
require_once(dirname(__FILE__)."/stourtravel/inc/inc_file.php");

$dsql->safeCheck = false; //关闭安全检查

addHtaccess();



//增加伪静态规则
function addHtaccess()
{
    $ifile = new iFile('.htaccess','r');
    $content=$ifile->readcontent();//获取文件内容
    $ifile->closefile();//文件关闭
    $ifiles = new iFile('./.htaccess','w');
    $new = "RewriteRule ^lines/([a-z0-9]+)-0-0-([0-9]+)-([0-9]+)-([0-9]+)-([^-]+)-([0-9]+)-([0-9_]+)?$ lines/search.php?dest_id=$1&day=$2&priceid=$3&sorttype=$4&keyword=$5&startcity=$6&attrid=$7

RewriteRule ^lines/([a-z0-9]+)-0-0-([0-9]+)-([0-9]+)-([0-9]+)-([^-]+)-([0-9]+)-([0-9_]+)-([0-9]+)?$ lines/search.php?dest_id=$1&day=$2&priceid=$3&sorttype=$4&keyword=$5&startcity=$6&attrid=$7&pageno=$8";
    $ifiles->writefile($content . "\r\n" . $new);

}



