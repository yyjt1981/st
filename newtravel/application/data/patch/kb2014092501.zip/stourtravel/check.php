<?php
header("location:{$GLOBAL['cfg_basehost']}/newtravel/");
exit;
@session_start();
$needCheck=1;//uplodify检测
if ($_SERVER['HTTP_USER_AGENT'] == 'Shockwave Flash') 
{        
  $needCheck=0; // avoid uplodify check.  
}
if($needCheck)
{
	if(!isset($_SESSION['admin_user']) && !isset($_COOKIE['admin_user']))
	{
		header("location:st_login.php");
	}
	else if(isset($_COOKIE['admin_user'])&&!isset($_SESSION['admin_user']))
	{
		$sql="select * from #@__admin where username='{$_COOKIE['admin_user']}'";
		
		$curuser=$dsql->GetOne($sql);
		
		if(empty($curuser))
		{
			header("location:st_login.php");
		}
		 
		 $_SESSION['uid']=$curuser['id'];
		 $_SESSION['admin_user']=$curuser['username'];
		 $_SESSION['roleid']=$curuser['roleid'];
		 $_SESSION['realname']=$curuser['roleid'];
	
	}
}

function checkUserRight($moduleid,$right,$type=true)
{   
  //@session_start();
  global $dsql,$_SESSION;
  if(!isset($_SESSION['roleid']))
   {
	   header("location:st_login.php");
	   exit();
   }
  $roleid=$_SESSION['roleid'];
  $right = getLoginUserRight($right,$moduleid,$roleid);

  if($type)
	 { 
		  if(1 != $right)
		  {
			 
			  ShowMsg('你没有权限执行此操作,请联系管理员提升权限!', '-1','1');
			  exit;
		  }  
	 }
	 else
	 {
		  if(1 != $right)
		  {
			  return false;
			  
		  }
		   
		 return true; 
	 }
	
}

//获取具体操作权限
function getLoginUserRight($rightfield,$moduleid,$roleid)
{
	global $dsql;
	$changemodule = array(4,5,6,9);
    $moduleid = in_array($moduleid,$changemodule) ? 4 : $moduleid;//这里由于整改了结构,用此方法兼容.
    $moduleid = $moduleid == 7 ? 5 : $moduleid;
	$sql="select {$rightfield} as sright from #@__role_module where roleid='$roleid' and moduleid='$moduleid'"; 	
    $row=$dsql->GetOne($sql);
	//echo $sql;
	//print_r($row);
	//exit;
	return isset($row['sright']) ? $row['sright'] : 0;
	
}