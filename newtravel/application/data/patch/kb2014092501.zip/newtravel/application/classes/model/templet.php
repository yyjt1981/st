<?php defined('SYSPATH') or die('No direct access allowed.');

class Model_Templet extends ORM {

    protected  $_table_name = 'templet';
    

}