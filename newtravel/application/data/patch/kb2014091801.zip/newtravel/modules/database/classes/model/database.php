<?php defined('SYSPATH') OR die('No direct script access.');

abstract class Model_Database extends Kohana_Model_Database {}
