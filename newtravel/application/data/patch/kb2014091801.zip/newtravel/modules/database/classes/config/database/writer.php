<?php defined('SYSPATH') OR die('No direct script access.');

/**
 * Transparent extension for the Kohana_Config_Database_Writer class
 *
 * @package    Kohana/Database
 * @category   Configuration
 * @author     Kohana Team
 * @copyright  (c) 2012 Kohana Team
 * @license    http://kohanaframework.org/license
 */
class Config_Database_Writer extends Kohana_Config_Database_Writer
{
	
}
